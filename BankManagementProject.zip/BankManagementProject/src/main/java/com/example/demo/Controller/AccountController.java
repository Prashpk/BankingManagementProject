package com.example.demo.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Service.AccountService;
import com.example.demo.Entity.Accounts;
import com.example.demo.Error.AccountNotFoundException;

@RestController
public class AccountController {

	@Autowired
	private AccountService accountService;
	
	// createAccount happens upon createCustomer
	public void createAccount(int acctID, int balance, String acctStatus) {
		Accounts acct = new Accounts(acctID, balance, acctStatus);
		accountService.createAccount(acct);
	}
	
	// getAll Account Details
	@GetMapping("/account/")
	public List<Accounts> fetctAccountsList() {
		return accountService.fetchAccountList();
	}
	
	// checkBalance
	@GetMapping("/account/{acctID}/balance")
	public int getBalance(int acctID) throws AccountNotFoundException{
		return accountService.getBalance(acctID);
	}
	
	// depositAmount
	@PutMapping("/account/{acctID}/deposit/{amount}")
	public String depositAmount(@PathVariable int acctID, @PathVariable int amount) {
		try {
			accountService.depositAmount(acctID, amount);
		} catch (AccountNotFoundException e) {

			e.addSuppressed(e);
		}
		return "Deposited the Amount Successfully!!";
	}
	
	// withdrawAmount
	@PutMapping("/account/{acctID}/withdraw/{amount}")
	public String withdrawAmount(@PathVariable  int acctID, @PathVariable int amount) throws AccountNotFoundException{
		try {
			if(amount > getBalance(acctID)) {
				throw new AccountNotFoundException("Insufficient Balance");

			}
			else {	
		    accountService.withdrawAmount(acctID, amount);
			}
		}
		catch(AccountNotFoundException e ){
		e.addSuppressed(e);
		}
		 return "Amount Withdrawn Successfully!";
	}
	
	

	// transferAmount
	@PutMapping("/account/{acctID}/transfer/{destAcctID}/{amount}")
	public String transferAmount(@PathVariable int acctID, @PathVariable int destAcctID, @PathVariable int amount) throws AccountNotFoundException{
		try {
		if(amount > getBalance(acctID)) {
			throw new AccountNotFoundException("Insufficient Balance");

		}
		else {
		accountService.transferAmount(acctID, destAcctID, amount);
		}
		}
		catch(Exception e) {
			e.addSuppressed(e);
		}
		return "Amount Transferred Successfully!";
	}
	
	// deleteAccount by id
	@DeleteMapping("/account/{acctID}")
	public String deleteAccount(@PathVariable int acctID) throws AccountNotFoundException{
		accountService.deleteAccount(acctID);
		return "Account Deleted Successfully!!";
		
	}
	// getAccountInfo
	@GetMapping("/account/{acctID}")
	public Accounts getAccountInfo(@PathVariable int acctID) throws AccountNotFoundException{
		return accountService.getAccountInfo(acctID);
	}
	

}
