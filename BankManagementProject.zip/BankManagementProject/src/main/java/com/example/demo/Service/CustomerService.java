package com.example.demo.Service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.Entity.Customer;
import com.example.demo.Error.CustomerNotFoundException;

@Service
public interface CustomerService {

	Customer createCustomer(Customer customer);

	Customer getCustomerInfo(int acctID) throws CustomerNotFoundException;

	void deleteCustomer(int acctID) throws CustomerNotFoundException;

	List<Customer> fetchCustomerList();

	void updateCustomerName(int acctId, String custName) throws CustomerNotFoundException;

	void updateCustomerCity(int acctID, String city);

	void changeCustomerState(int acctID, String state);

	void changeCustomerCountry(int acctID, String country);

	void changeCustomerPassword(int acctID, String password);

	void changeCustomerPhoneNo(int acctID, String phoneNo);
}
